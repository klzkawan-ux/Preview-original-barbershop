import { useEffect, useRef } from "react";

export function MagneticCursor() {
  const cursor = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!window.matchMedia("(pointer: fine) and (prefers-reduced-motion: no-preference)").matches) return;
    const el = cursor.current;
    if (!el) return;
    const move = (event: PointerEvent) => {
      el.style.transform = `translate3d(${event.clientX}px, ${event.clientY}px, 0)`;
      el.classList.add("cursor-visible");
      const interactive = event.target instanceof Element && Boolean(event.target.closest("a, button, .logo-stage"));
      el.classList.toggle("cursor-active", interactive);
    };
    const hide = () => el.classList.remove("cursor-visible");
    window.addEventListener("pointermove", move);
    document.addEventListener("pointerleave", hide);
    return () => { window.removeEventListener("pointermove", move); document.removeEventListener("pointerleave", hide); };
  }, []);
  return <div className="magnetic-cursor" ref={cursor} aria-hidden="true"><span /></div>;
}