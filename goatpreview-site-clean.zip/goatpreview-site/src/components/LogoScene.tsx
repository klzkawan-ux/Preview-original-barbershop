import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Lightformer } from "@react-three/drei";
import { Component, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import contours from "@/assets/logo-contours.json";
import logo from "@/assets/goat-mark.png.asset.json";

type Motion = { yaw: number; pitch: number; dragging: boolean; reduced: boolean };

function Sculpture({ motion }: { motion: React.RefObject<Motion> }) {
  const group = useRef<THREE.Group>(null);
  const geometry = useMemo(() => {
    const shapes = contours.map(({ outer, holes }) => {
      const points = outer.map(([x = 0, y = 0]) => new THREE.Vector2((x - 589.5) / 280, (833 - y) / 280));
      const shape = new THREE.Shape(points);
      shape.holes = holes.map((hole) => new THREE.Path(hole.map(([x = 0, y = 0]) => new THREE.Vector2((x - 589.5) / 280, (833 - y) / 280))));
      return new THREE.ExtrudeGeometry(shape, { depth: 0.19, bevelEnabled: true, bevelThickness: 0.018, bevelSize: 0.014, bevelSegments: 2, steps: 1, curveSegments: 6 });
    });
    const merged = mergeGeometries(shapes);
    shapes.forEach((g) => g.dispose());
    return merged ?? new THREE.BufferGeometry();
  }, []);
  const surface = useMemo(() => {
    const values = new Uint8Array(64 * 64 * 4);
    for (let i = 0; i < 64 * 64; i++) {
      const shade = (i * 197 + 61) % 256;
      values.set([shade, shade, shade, 255], i * 4);
    }
    const texture = new THREE.DataTexture(values, 64, 64);
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(3, 3);
    texture.needsUpdate = true;
    return texture;
  }, []);
  const color = useMemo(() => {
    const value = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--logo-albedo"));
    return new THREE.Color().setScalar(Number.isFinite(value) ? value : 0.85);
  }, []);
  useEffect(() => () => { geometry.dispose(); surface.dispose(); }, [geometry, surface]);
  useFrame(({ clock }, rawDelta) => {
    const mesh = group.current;
    if (!mesh) return;
    const dt = Math.min(rawDelta, 0.05);
    if (!motion.current.dragging && !motion.current.reduced) motion.current.yaw += dt * 0.72;
    mesh.rotation.y = THREE.MathUtils.damp(mesh.rotation.y, motion.current.yaw, 14, dt);
    mesh.rotation.x = THREE.MathUtils.damp(mesh.rotation.x, motion.current.pitch, 14, dt);
    mesh.rotation.z = motion.current.reduced ? 0 : Math.sin(clock.elapsedTime * 1.15) * 0.045;
    mesh.position.y = motion.current.reduced ? 0 : Math.sin(clock.elapsedTime * 1.3) * 0.065;
  });
  return <group ref={group}><mesh geometry={geometry} position-z={-0.095}><meshStandardMaterial color={color} metalness={0.32} roughness={0.35} roughnessMap={surface} bumpMap={surface} bumpScale={0.009} /></mesh></group>;
}

class SceneBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  override render() { return this.state.failed ? <img className="logo-fallback" src={logo.url} alt="GOAT skull logo" /> : this.props.children; }
}

export default function LogoScene() {
  const motion = useRef<Motion>({ yaw: -0.12, pitch: -0.06, dragging: false, reduced: false });
  const last = useRef({ x: 0, y: 0 });
  const [ready, setReady] = useState(false);
  const [supported, setSupported] = useState(false);
  useEffect(() => {
    motion.current.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const canvas = document.createElement("canvas");
    setSupported(Boolean(canvas.getContext("webgl2") || canvas.getContext("webgl")));
  }, []);
  return (
    <div className="logo-stage" role="img" aria-label="Rotating three-dimensional GOAT skull logo" tabIndex={0}
      onPointerDown={(e) => { motion.current.dragging = true; last.current = { x: e.clientX, y: e.clientY }; e.currentTarget.setPointerCapture(e.pointerId); }}
      onPointerMove={(e) => { if (!motion.current.dragging) return; motion.current.yaw += (e.clientX - last.current.x) * 0.012; motion.current.pitch = THREE.MathUtils.clamp(motion.current.pitch + (e.clientY - last.current.y) * 0.008, -0.9, 0.9); last.current = { x: e.clientX, y: e.clientY }; }}
      onPointerUp={() => { motion.current.dragging = false; }} onPointerCancel={() => { motion.current.dragging = false; }}
      onKeyDown={(e) => { if (e.key === "ArrowLeft" || e.key === "ArrowRight") { e.preventDefault(); motion.current.yaw += e.key === "ArrowLeft" ? -0.3 : 0.3; } }}>
      <img className={`logo-fallback ${ready ? "logo-fallback-hidden" : ""}`} src={logo.url} alt="" />
      {supported && <SceneBoundary><Canvas dpr={[1, 1.5]} camera={{ position: [0, 0, 7.4], fov: 37 }} gl={{ antialias: true, alpha: true, powerPreference: "low-power" }} onCreated={() => setReady(true)}>
        <ambientLight intensity={1.3} />
        <directionalLight position={[3, 4, 6]} intensity={3} />
        <directionalLight position={[-4, -2, 3]} intensity={1.4} />
        <Environment resolution={64}><Lightformer intensity={3} position={[0, 5, 0]} scale={[10, 10, 1]} /><Lightformer intensity={2} position={[-5, 0, 2]} rotation-y={Math.PI / 2} scale={[10, 3, 1]} /></Environment>
        <Sculpture motion={motion} />
      </Canvas></SceneBoundary>}
    </div>
  );
}