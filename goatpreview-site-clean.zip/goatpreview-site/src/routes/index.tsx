import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useState } from "react";
import { ArrowUpRight, ArrowDown, MapPin, Star, Phone, Menu, X, Scissors, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MagneticCursor } from "@/components/MagneticCursor";
import { shop } from "@/lib/barbershop";
import logo from "@/assets/goat-mark.png.asset.json";
import storefront from "@/assets/storefront.jpg.asset.json";
import detail from "@/assets/storefront-detail.jpg.asset.json";
import interior from "@/assets/interior.jpg.asset.json";

const LogoScene = lazy(() => import("@/components/LogoScene"));

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({ meta: [
    { title: "GOAT Barber Shop — Make Your Mark | Katy, TX" },
    { name: "description", content: "Stand out at GOAT Barber Shop. Visit us at 2501 N Fry Rd, Ste H, Katy, Texas. Get directions, explore our shop, and share your experience." },
    { property: "og:title", content: "GOAT Barber Shop — Make Your Mark" },
    { property: "og:description", content: "Not just a cut. A statement. Discover GOAT Barber Shop in Katy, Texas." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

function Index() {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <div className="site-shell" id="top">
      <MagneticCursor />
      <header className="site-header">
        <a href="#top" className="brand" aria-label="GOAT Barber Shop home"><img src={logo.url} alt="" /><span>GOAT<span className="brand-sub">BARBER SHOP</span></span></a>
        <nav className="desktop-nav" aria-label="Main navigation"><Button variant="navigation" asChild><a href="#experience">The experience</a></Button><Button variant="navigation" asChild><a href="#visit">Find us</a></Button><Button variant="navigation" asChild><a href="#reviews">The GOAT effect</a></Button></nav>
        <Button variant="neonOutline" asChild className="header-cta"><a href={shop.phoneHref}>LET’S TALK <ArrowUpRight /></a></Button>
        <Button variant="navigation" size="icon" className="mobile-menu-toggle" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</Button>
        {menuOpen && <nav className="mobile-nav" aria-label="Mobile navigation">{[["The experience", "#experience"], ["Find us", "#visit"], ["The GOAT effect", "#reviews"]].map(([label, href]) => <Button key={href} variant="navigation" asChild><a href={href} onClick={() => setMenuOpen(false)}>{label}<ArrowUpRight /></a></Button>)}</nav>}
      </header>
      <main>
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero-topline"><span><i /> KATY, TEXAS</span><span>GREATNESS IS A CHOICE.</span></div>
          <div className="hero-ghost" aria-hidden="true">GOAT</div>
          <Suspense fallback={<div className="logo-stage"><img className="logo-fallback" src={logo.url} alt="GOAT skull logo" /></div>}><LogoScene /></Suspense>
          <div className="hero-content"><div className="eyebrow"><span className="short-line" /> NOT JUST A CUT. A STATEMENT.</div><h1 id="hero-title">GOAT<span>BARBER SHOP<span className="title-period">.</span></span></h1><p>Built for those who don’t blend in.<br />Walk in yourself. Walk out a legend.</p><div className="hero-actions"><Button variant="neon" asChild><a href="#experience">FIND YOUR GOAT ENERGY <ArrowUpRight /></a></Button><a className="hero-location" href={shop.directions} target="_blank" rel="noopener noreferrer"><MapPin size={16} /> KATY, TX <ArrowUpRight size={14} /></a></div></div>
          <div className="hero-bottom"><a className="scroll-link" href="#experience"><ArrowDown size={16} /> DISCOVER THE DIFFERENCE</a><span>PRECISION. PERSONALITY. PRESENCE.</span><span className="edition">01 / GOAT</span></div>
        </section>
        <div className="manifesto-strip" aria-hidden="true"><span>LOOK SHARP.</span><span className="strip-star">✳</span><span>STAND APART.</span><span className="strip-star">✳</span><span>BE THE GOAT.</span><span className="strip-star">✳</span><span>LOOK SHARP.</span><span className="strip-star">✳</span></div>
        <section className="experience section-wrap" id="experience">
          <div className="section-caption"><span>01 / THE EXPERIENCE</span><span>MORE THAN A BARBERSHOP</span></div>
          <div className="experience-grid"><div className="experience-copy"><h2>YOUR STYLE.<br />YOUR STATEMENT.</h2><p>A fresh cut changes more than your look. It changes how you show up.</p><p>At GOAT Barber Shop, make room for a little time in the chair — and a whole new level of confidence.</p><div className="experience-values"><span><Scissors size={18} /> THE DETAILS MATTER</span><span><Star size={18} /> CONFIDENCE COMES STANDARD</span></div><Button variant="neonOutline" asChild><a href={shop.phoneHref}>READY FOR YOUR NEXT CHAPTER? <ArrowUpRight /></a></Button></div><figure className="experience-image"><img src={interior.url} alt="The real interior of GOAT Barber Shop, with barber chairs, mirrors and waiting area" loading="lazy" /><figcaption><span>INSIDE GOAT / KATY, TX</span><a href="https://maps.google.com/maps/contrib/100654428453737764799" target="_blank" rel="noopener noreferrer">PHOTO: DAVID HERNANDEZ REYES</a></figcaption></figure></div>
        </section>
        <section className="visit section-wrap" id="visit">
          <div className="section-caption"><span>02 / FIND YOUR CHAIR</span><span>YOUR NEXT STOP: GOAT</span></div>
          <div className="visit-heading"><h2>GREATNESS.<br />RIGHT THIS WAY.</h2><p>Your new favorite spot.<br />In the heart of Katy, Texas.</p></div>
          <div className="visit-grid"><div className="storefront-images"><figure className="storefront-main"><a href={shop.directions} target="_blank" rel="noopener noreferrer" aria-label="Get directions to the GOAT Barber Shop storefront"><img src={storefront.url} alt="GOAT Barber Shop storefront on North Fry Road in Katy, Texas" loading="lazy" /><span className="image-arrow"><ArrowUpRight /></span></a><figcaption>PHOTO: GOAT BARBERSHOP · GOOGLE MAPS</figcaption></figure><figure className="storefront-secondary"><img src={detail.url} alt="A closer view of the GOAT Barber Shop sign and entrance" loading="lazy" /><figcaption>PHOTO: JOSE MATOS HERNANDEZ</figcaption></figure></div><div className="visit-details"><div className="detail-block"><div className="eyebrow"><MapPin size={15} /> THE ADDRESS</div><a className="address-link" href={shop.directions} target="_blank" rel="noopener noreferrer">{shop.address}<br />{shop.locality}<ArrowUpRight /></a><Button variant="neon" asChild><a href={shop.directions} target="_blank" rel="noopener noreferrer">GET DIRECTIONS <ArrowUpRight /></a></Button></div><div className="detail-block"><div className="eyebrow"><Clock size={15} /> THE HOURS</div>{shop.hours.map((hour) => <div className="hours-row" key={hour.days}><span>{hour.days}</span><span>{hour.time}</span></div>)}</div><div className="detail-block phone-block"><span><Phone size={15} /> A GOOD CUT STARTS WITH A HELLO.</span><a href={shop.phoneHref}>{shop.phone}<ArrowUpRight size={18} /></a></div></div></div>
        </section>
        <section className="reviews section-wrap" id="reviews"><div className="section-caption"><span>03 / THE GOAT EFFECT</span><span>REAL PEOPLE. REAL CONFIDENCE.</span></div><div className="review-content"><div className="rating-line"><span className="stars" aria-label="Five stars">{[1, 2, 3, 4, 5].map((n) => <Star key={n} size={21} fill="currentColor" />)}</span><span>{shop.rating} ON GOOGLE · {shop.reviewCount} REVIEWS</span></div><h2>GOT THE LOOK?<br /><span className="outline-text">GIVE US THE LOVE.</span></h2><p>Your experience deserves to be heard.<br />Leave your mark. Join the GOATs.</p><Button variant="neon" asChild><a href={shop.review} target="_blank" rel="noopener noreferrer">DROP A REVIEW. BE A GOAT. <ArrowUpRight /></a></Button><a className="review-secondary" href={shop.maps} target="_blank" rel="noopener noreferrer">SEE WHAT PEOPLE ARE SAYING <ArrowUpRight size={14} /></a></div></section>
        <section className="final-call section-wrap"><div><span className="eyebrow">INTERESTED? MAKE IT HAPPEN.</span><h2>DON’T JUST LOOK.<br />BECOME THE GOAT.</h2></div><Button variant="neonOutline" asChild><a href="#visit">MEET YOUR NEXT BARBERSHOP <ArrowUpRight /></a></Button></section>
      </main>
      <footer className="site-footer"><a className="brand" href="#top"><img src={logo.url} alt="" /><span>GOAT<span className="brand-sub">BARBER SHOP</span></span></a><span>KATY, TEXAS. A CUT ABOVE.</span><a href="#top">BACK TO TOP <ArrowUpRight size={14} /></a></footer>
    </div>
  );
}
