import { describe, expect, it } from "vitest";
import { shop } from "./barbershop";

describe("GOAT destinations", () => {
  it("opens directions rather than a place search", () => {
    const url = new URL(shop.directions);
    expect(url.pathname).toBe("/maps/dir/");
    expect(url.searchParams.get("destination_place_id")).toBe("ChIJqSXBabzZQIYRqCc42VRBAB4");
  });
  it("opens the review form for the same venue without inventing a selected rating", () => {
    const url = new URL(shop.review);
    expect(url.pathname).toBe("/local/writereview");
    expect(url.searchParams.get("placeid")).toBe(shop.placeId);
    expect(url.searchParams.has("rating")).toBe(false);
  });
});