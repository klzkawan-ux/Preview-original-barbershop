export const shop = {
  name: "GOAT Barber Shop",
  address: "2501 N Fry Rd, Ste H",
  locality: "Katy, TX 77449",
  phone: "(346) 818-7682",
  phoneHref: "tel:+13468187682",
  placeId: "ChIJqSXBabzZQIYRqCc42VRBAB4",
  directions: "https://www.google.com/maps/dir/?api=1&destination=2501%20N%20Fry%20Rd%20Ste%20H%2C%20Katy%2C%20TX%2077449&destination_place_id=ChIJqSXBabzZQIYRqCc42VRBAB4",
  review: "https://search.google.com/local/writereview?placeid=ChIJqSXBabzZQIYRqCc42VRBAB4",
  maps: "https://maps.google.com/?cid=2161799653815232424",
  rating: 4.8,
  reviewCount: 68,
  hours: [
    { days: "Monday — Saturday", time: "10 AM — 8 PM" },
    { days: "Sunday", time: "10 AM — 7 PM" },
  ],
} as const;