# GOAT Barber Shop — Site

Site oficial da GOAT Barber Shop (Katy, Texas). Preto e branco, logo 3D interativa,
fotos reais da fachada, rota direta no Google Maps e botão de avaliação.

Stack: TanStack Start (React 19) + Vite 7 + Tailwind CSS v4 + React Three Fiber.

## Rodando localmente

Precisa de Node.js 20+ e npm.

```sh
npm install
npm run dev
```

Abra http://localhost:8080

Outros comandos:

```sh
npm run build     # build de produção
npm run preview   # serve o build
npm run test      # testes (vitest)
npm run lint      # eslint
```

## Estrutura

- `src/routes/index.tsx` — a página inteira
- `src/components/LogoScene.tsx` — logo 3D (arrastar para girar)
- `src/components/MagneticCursor.tsx` — cursor neon
- `src/lib/barbershop.ts` — endereço, telefone, horários e links (mexa aqui para trocar dados)
- `src/assets/` + `public/assets/` — imagens e contornos da logo

As imagens estão copiadas em `public/assets/`, então o site funciona sem depender
do hospedamento da Lovable.

## Observação

O Google não permite pré-selecionar 5 estrelas no link de avaliação: o visitante
escolhe as estrelas na página do Google.
